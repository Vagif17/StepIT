number = int(input('Enter number:'))
num= 0
while num != 10:
    num += 1
    print(num * number)