int comparisons (char* w1,char* w2);
int length(char* w1);
char* intToStr(int w1[]);
char* upperCase(char* w1);
char* lowerCase(char* w1);
char* reverse(char* w1);