#include <iostream>
#include "String.h"
using namespace std;
int main(){
    // Task 6
    char* word = "Hello";
    cout << reverse(word);
    return 0;
}