#include <iostream>
#include "String.h"
using namespace std;
int main() {
    // Task 2
    char* word = "Step IT Academy";
    return length(word);
}