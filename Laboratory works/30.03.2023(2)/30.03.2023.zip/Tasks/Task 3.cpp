#include <iostream>
#include "String.h"
using namespace std;
int main(){
    // Task 3
    int intWord[]{80,82,73,86,69,84};
    cout << intToStr(intWord,len);
}