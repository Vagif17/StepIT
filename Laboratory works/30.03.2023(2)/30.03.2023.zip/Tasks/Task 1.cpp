#include <iostream>
#include "String.h"
using namespace std;
int main() {
    // Task 1
    char* word1 = "Hello"; // Можно изменить что бы убедиться что программа работает.
    char* word2 = "World";
    return  comparisons(word1,word2);
}
