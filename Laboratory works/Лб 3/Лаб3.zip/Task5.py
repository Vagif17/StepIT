time = int(input("Enter time:"))
if time <6 >=0:
    print('Good Night')
elif time <13 >=6:
    print('Good Morning')
elif time <17 >=13:
    print("Good Day")
elif time >=17 <23:
    print("Good Evening")