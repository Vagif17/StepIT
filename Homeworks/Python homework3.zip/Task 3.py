Nar = 0.70
Azercell = 0.35
Bakcell = 0.90
print('1. Nar = .070 \n 2. Azercell = 0.35 \n 3. Backell = 0.90 ')
act_1 = int(input('From which operator will call:'))
act_2 = int(input('To which operator will call:'))
if act_1 == 1 and act_2 == 1:
    print(Nar + Nar)
elif act_1 == 1 and act_2 == 2:
    print(Nar + Azercell)
elif act_1 == 1 and act_2 == 3:
    print(Nar + Bakcell)
elif act_1 == 2 and act_2 == 1:
    print(Azercell + Nar)
elif act_2 == 2 and act_3 == 2:
    print(Azercell + Azercell)
elif act_1 == 2 and act_2 == 3:
    print(Azercell + Bakcell)
elif act_1 == 3 and act_2 == 1:
    print(Bakcell + Nar)
elif act_1 == 3 and act_2 == 2:
    print(Bakcell + Azercell )
elif act_1 == 3 and act_2 == 3:
    print(Bakcell + Bakcell)
