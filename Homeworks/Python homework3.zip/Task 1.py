number_1 = int(input('Enter a number from 1 to 100:'))
if number_1 > 100:
    print('Error: Number is greater than 100')
elif number_1 % 3 == 0 and number_1 % 5 == 0:
    print('Fizz Buzz')
elif number_1 % 3 == 0:
    print('Fizz')
elif number_1 % 5 == 0:
    print('Buzz')
else:
    print(number_1)