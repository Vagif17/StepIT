manager_salary = 200
sales_1 = int(input('Enter sales of first manager:'))
sales_2 = int(input('Enter sales of second manager:'))
sales_3 = int(input('Enter sales of third manager:'))
if sales_1 > 1000:
    print('First manager salary = ', end="")
    print(manager_salary + (sales_1 / 100) * 8 )
elif 500 <= sales_1  <= 1000:
    print('First manager salary = ', end="")
    print (manager_salary + (sales_1 / 100) * 5 )
elif sales_1 < 499:
    print('First manager salary = ', end="")
    print(manager_salary + (sales_1 / 100) *3)
if sales_2 > 1000:
    print('Second manager salary = ', end="")
    print(manager_salary + (sales_2 / 100) * 8 )
elif 500 <= sales_2 <= 1000:
    print('Second manager salary = ', end="")
    print(manager_salary + (sales_2 / 100) * 5 )
elif sales_2 < 499 :
    print('Second manager salary = ', end="")
    print(manager_salary + (sales_2 / 100) * 3 )
if sales_3 > 1000:
    print('Third manager salary = ', end="")
    print(manager_salary + (sales_3 / 100) * 8 )
elif 500 <= sales_3 >= 1000:
    print('Third manager salary = ', end="")
    print(manager_salary + ( sales_3 / 100) * 5 )
elif sales_3 < 499:
    print('Third manager salary = ', end="")
    print(manager_salary + (sales_3 / 100) * 3 )
if sales_3 < sales_1 > sales_2:
    print('First manager is the best manager and as a reward he receives + 200 to his salary')
elif sales_1 < sales_2 > sales_3:
    print('Second manager is the best manager and as a reward he receives + 200 to his salary')
else:print('Third manager the best manager and as a reward he receives + 200 to his salary')