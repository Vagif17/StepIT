number_1 = int(input('Enter the number:'))
degree = int(input('Enter a degree from 0 to 7:'))
print(number_1 ** degree)