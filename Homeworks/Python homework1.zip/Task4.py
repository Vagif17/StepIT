print('to be')
print('or not')
print('to be')