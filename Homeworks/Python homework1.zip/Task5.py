print('"Life is what happens')
print('\twhen')
print('\t\tyou’re busy making other plans”')
print('\t\t\t\t\t\t\t\t\tJohn Lennon.')