#Diagonal AC
diagonal_ac = int(input("Enter diagonal AC:"))
#Diagonal BD
diagonal_bd = int(input("Enter diagonal BD:"))
#Rhombus
print("The perimeter of the rhombus=", end='')
print(f"{diagonal_ac} * {diagonal_bd} / {2} = {diagonal_ac * diagonal_bd / 2}")