#User Salary
monthly_salary = int(input('Enter your monthly salary:'))
#Loan payment
loan_payment = int(input('Enter your loan payment:'))
#Utility bills
utility_bills = int(input('Enter your utility bills:'))
print(f"{monthly_salary} - {loan_payment} - {utility_bills} = {monthly_salary - loan_payment - utility_bills}")
print('Your balance='f"{monthly_salary - loan_payment - utility_bills}")