#Number1
Number1 = int(input('Enter your first number:'))
#Number2
Number2 = int(input('Enter your second nubmer:'))
#Number3
Number3 = int(input('Enter your third nubmer:'))

print(f"{Number1} + {Number2} + {Number3} = {Number1 + Number2 + Number3}")

print(f"{Number1} * {Number2} * {Number3} = {Number1 * Number2 * Number3}")
