#С пробелом
# number = str(input('Enter an example:'))
# number = number.split()
# number_1 = int(number[0])
# number_2 = int(number[2])
# for i in number:
#     if i == '+':
#         print(number_1 + number_2)
#     elif i == '-':
#         print(number_1 - number_2)
#     elif i == '*':
#         print(number_1 * number_2)
#     elif i == '/':
#         print(number_1 / number_2)

#Без пробела
number = str(input('Enter an example:'))
number_1 = 0

for i in number:
    if i.isnumeric():
        int(i)
        