number = (-29,2,-20,30,0,0,10)
zero = 0
negative = 0
positive = 0
for i in number:
    if i == 0:
        zero += 1
    if i < 0:
        negative += 1
    if i > 0:
        positive += 1
print(f'Positive numbers = {positive}')
print(f'Negative numbers = {negative}')
print(f'Zero numbers = {zero}')
smallest_n = number[0]
biggest_n = number[0]
for i in number:
    if i > biggest_n:
        biggest_n = i
print(f'Biggest number = {biggest_n}')
for b in number:
    if b < smallest_n:
        smallest_n = b
print(f'Smallest number = {smallest_n}')
