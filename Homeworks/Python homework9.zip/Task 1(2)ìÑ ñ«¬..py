#Без пробела
number = str(input('Enter an example:'))
lent = 10
count = 0
res = 0
negative_res = 0
for i in number:
    if i.isnumeric():
        count += 1
    if i == '+':
        break
count_end = count
for j in number:
    if j == '+':
        count = 0
        for j in number:
            if j.isnumeric():
                count += 1
            if j == '+':
                count = 0
    if j.isnumeric():
        j = int(j)
        if count == 2:
            j *= 10
            count -= 1
            res += j
        elif count == 1:
            res += j
        if count == count_end:
            lent **= count
        if count > 2:
            lent //= 10
            j *= lent
            res += j
            count -= 1
print(res)
