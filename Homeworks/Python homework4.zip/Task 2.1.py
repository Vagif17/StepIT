number_1 = int(input('Enter first number:'))
number_2 = int(input('Enter second number:'))
stop_1 = number_1
stop_2 = number_2
num_1 = number_1
num_2 = number_2
Num_ber_1 = number_1
Num_ber_2 = number_2
print('All numbers -')
print(number_1)
while number_1 != number_2:
    number_1 += 1
    print(number_1)

print('\n All numbers descending order -')
print(stop_2)
while stop_1 != stop_2:
    stop_2 -= 1
    print(stop_2)

print('\n All numbers divisible by 7 -')
if num_1 % 7 ==0:
    print(num_1)
while num_1 != num_2:
    num_1 += 1
    if num_1 % 7 == 0:
        print(num_1)

print('\n Number of multiples of 5 -')
count = 1
if Num_ber_1 % 5 == 0:
    print(f'{count}. {Num_ber_1}')
while Num_ber_1 != Num_ber_2:
    Num_ber_1 += 1
    if Num_ber_1  % 5 ==0:
        count += 1
        print(f'{count}. {Num_ber_1}')
