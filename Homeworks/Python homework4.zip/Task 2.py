number_1 = int(input('Enter first number:'))
number_2 = int(input("Enter second number:"))
choice = int(input('Choice act : \n 1. All numbers \n 2. Do descending order \n 3. All numbers divisible by 7 \n 4. Number of multiples of 5 \n :  '))
if number_1 > number_2:
    print('Error: First number bigger than second')
elif number_1 < number_2 and choice == 1:
    print(number_1)
    while number_1 != number_2:
        number_1 += 1
        print(number_1)
if choice == 2:
    print(number_2)
    while number_2 != number_1:
        number_2 -=1
        print(number_2)
if choice == 3:
    while number_1 != number_2:
        number_1 += 1
        if number_1 % 7 == 0:
            print(number_1)
if choice == 4:
    if number_1 % 5 == 0:
        count = 1
        print(f'{count}. {number_1}')
        while number_1 != number_2:
            number_1 += 1
            count += 1
            print(f'{count}. {number_1}')
print(f"Number of multiples of 5 - {count} ")
