number_1 = int(input('Enter first number:'))
number_2 = int(input('Enter second number:'))
if number_1 % 3 == 0 and number_1 % 5 == 0:
    print(f'{number_1} = Fizz Buzz')
elif number_1 % 3 == 0:
    print(f'{number_1} - Fizz')
elif number_1 % 5 == 0:
    print(f'{number_1} - Buzz')
else:print(number_1)
while number_1 != number_2:
    number_1 += 1
    if number_1 % 3 ==0 and number_1 % 5 == 0:
        print(f'{number_1} - Fizz Buzz')
    elif number_1 % 3 == 0:
        print(f'{ number_1} - Fizz')
    elif number_1 % 5 == 0:
        print(f'{number_1} - Buzz')
    elif number_1:
        print(number_1)