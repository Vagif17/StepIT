number_1 = int(input("Enter first number:"))
number_2 = int(input("Enter second number:"))
while number_1 != number_2:
    number_1 += 1
    if number_1 % 7 ==0:
        print(number_1)