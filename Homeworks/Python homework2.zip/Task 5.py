Number1 = int(input('Enter Number:'))
n1 = (Number1 % 100) % 10
n2 = (Number1 // 10) % 10
n3 = (Number1 // 100) % 10
n4 = Number1 // 1000
# print(n1)
# print(n2)
# print(n3)
# print(n4)
n_1 = n1 * 1000
n_2 = n2 * 100
n_3 = n3 * 10
print(n_1 + n_2 + n_3 + n4)