triangle_base = int(input('Enter the base of the triangle:'))
triangle_heiqh = int(input('Enter the height of the triangle:'))
print('Area of a triangle = ', end='')
print(triangle_heiqh * triangle_base / 2)
