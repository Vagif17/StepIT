Number = int(input('Enter Number:'))
n1 = Number //1000
n2 = (Number // 100) % 10
n3 = (Number // 10) % 10
n4 = (Number % 10)
# print(n1)
# print(n2)
# print(n3)
# print(n4)
print(n1 * n2 * n3 * n4)
