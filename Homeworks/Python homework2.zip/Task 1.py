Number_1 = int(input('Enter First Number:'))
Number_2 = int(input('Enter Second Number'))
Number_3 = int(input('Enter Third Number:'))

n1 = Number_1 * 100
n2 = Number_2 * 10
print(n1 + n2 + Number_3)