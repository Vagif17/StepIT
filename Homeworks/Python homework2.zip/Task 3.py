Meter = int(input('Enter Meters:'))
Centimeters = Meter * 100
Decimeters = Meter * 10
Millimeters = Meter * 1000
Miles = Meter * 0.000621
print ('Centimeters =', end='')
print (Centimeters)
print ('Decimeters =', end='')
print (Decimeters)
print('Millimeters =', end='')
print(Millimeters)
print('Miles=', end='')
print(Miles)

