numbers = (input('Enter number:').split())
numbers_1 = list(map(int(numbers)))
print(numbers_1)