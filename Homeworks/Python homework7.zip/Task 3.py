number = int(input('Enter number:'))
for i in range(number + 1):
    if number == 7:
        print('Good Bye!')
    elif number == 0:
        print('Number is equal to zero')
    elif number > 0:
        print('Number is positive')
        break
else:
    print('Number is negative')