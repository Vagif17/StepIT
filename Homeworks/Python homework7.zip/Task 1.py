number = int(input('Enter first number:'))
odd = 0                        #Нечётные
even = 0                       #Чётные
nine = 0
for i in range (number + 1 ):
    if i % 9 == 0:
        nine += i
    if i % 2 == 0:
        even += i
    if i % 2 != 0:
        odd += i
print(f'Odd numbers = {odd} ')
print(f'Even number = {even}')
print(f'Multiples of 9 = {nine} ')
odd_1 = 0
for i in range(odd + 1):
    if True:
        odd_1 += 1
print(f'\nArithmetic mean of {odd} = {odd_1 / odd} ')
even_1 = 0
if even >= 2:
    for i in range (even + 1 ):
        if True:
            even_1 += i
    print(f'\nArithmetic mean of {even} = {even_1 / even}')
nine_1 = 0
if nine >= 9:
    for i in range (nine + 1 ):
        if True:
            nine_1 += i
    print(f'\nArithmetic mean of {nine} = {nine_1 / nine }')
