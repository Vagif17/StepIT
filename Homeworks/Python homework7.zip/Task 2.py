number = int(input('Enter height:'))
symbol = input('Enter symbol:')
for i in range(number ):
    print(symbol)