def find_min(x:list):
    min = x[0]
    for i in (x):
        if i < min:
            min = i
    print(min)
list = [50,25,31,40,14,0,2,5,-23]
find_min(list)