def print_string():
    print('\"Dont compare yourself with anyone is the world... \n if you do so, you are insulting yourself.\"')
    print('\t \t \t \t \t \t \t \t \t \t Bill Gates')
print_string()