def multiple_in_rande(x,y):
    c = y
    multiple = 1
    if x > y:
        y = x
        x = c
    for i in range(x,y + 1):
        multiple *= i
    print(multiple)
multiple_in_rande(1,10)
