def nubmer (x,y):
    for i in range (x,y + 1):
        if i % 2 == 0:
            print(i)
nubmer(1,17)