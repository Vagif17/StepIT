def square(x,y,c):
    amount = 0
    nothing = '  '
    if c == False:
        y *= x
        while amount != x:
            amount += 1
            print(y)
    if c == True:
        while amount <= x:
            if amount == 0 or amount == x:
                print( nothing + y * x )
            else:print(' ', y, (x + 1) * ' ', y, sep='')
            amount += 1


square(5,'#',False)
square(7,'*',True)