def is_palindrom(x):
    palindrom = str(x)
    if palindrom == palindrom[::-1]:
        print('True')
    else:
        print('False')
is_palindrom(1221)