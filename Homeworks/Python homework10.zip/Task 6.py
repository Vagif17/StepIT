# С использованием Str
# def  amount_number(x:int):
#         print(len(str(x)))
# amount_number(15)


# Без Str
# def amount_number(x:int):
#     amount = 0
#     mulptiple = 10
#     for i in range(x + 1):
#         if i < 9:
#             amount = 1
#         if i >= mulptiple:
#             amount += 1
#             mulptiple *= 10
#     print(amount)
# amount_number(100)