name = input('Enter string:')
if name.lower() == name.lower()[::-1]:
    print('Yes')
else:
    print('No')
