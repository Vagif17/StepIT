name = input('Enter String:') # london is the capital of great britain and baku is capital of azerbaijan (Пример)
word_1 = 'london'
word_2 = 'baku'
word_3 = 'great britain'
word_4 = 'azerbaijan'
if word_1 in name:
    name = (name.replace(word_1,word_1.title()))
if word_2 in name:
    name = (name.replace(word_2,word_2.title()))
if word_3 in name:
    name = (name.replace(word_3,word_3.title()))
if word_4 in name:
    name = (name.replace(word_4,word_4.title()))
print(name)