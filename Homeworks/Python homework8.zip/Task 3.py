name = input('Enter string :')
strings = 0
symbol_1 = int(name.count('!'))
symbol_2 = int(name.count('?'))
symbol_3 = int(name.count('.'))
print(strings + symbol_1 + symbol_2 + symbol_3)
