def list_of_numbers(x:set,y:set):
    print(x.intersection(y))

list_1 = {1,2,3,4,5,6,7,8,}
list_2 = {3,5,7,1}

list_of_numbers(list_1,list_2)