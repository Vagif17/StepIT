def multiple_list(x):
    multiple_list_res = 1
    for i in range(len(x)):
        if i == 0:
            for b in x:
                multiple_list_res *= b
    return multiple_list_res
print(multiple_list([1,2,3,]))