def remove(x:list):
    new_list = []
    remove_numbers = [2,8,1]
    for i in range(len(x)):
        for b in x:
            for j in remove_numbers:
                if b == j:
                    x.remove(b)
                    new_list.append(b)
    print(new_list) # Удалённые цифры
    print(x) #Список без удалённых цифр


remove([1,10,9,-2,13,15,8,3,1,2])