def min_number(x):
    minimum = x[0]
    for i in x:
        if i < minimum:
            minimum = i
    print(minimum)
list_of_numbers = [10,2,50,3,1,13,12]
min_number(list_of_numbers)