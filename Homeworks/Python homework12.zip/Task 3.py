def number(x):
    amount = 0
    for i in x:
        for b in range(2, i + 1):
            if i == 2:
                amount += 1
            if i % b == 0:
                amount += 0
                break
            else:
                amount += 1
                break
    print(amount)


list_of_numbers = [2,3,4,6,8,10,11,13,19,119]
number(list_of_numbers)
