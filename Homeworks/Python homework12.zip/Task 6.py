def number(x):
    res_list = []
    degree = 3
    for i in x:
        i **= degree
        res_list.append(i)
    print(res_list)

first_list = [2,4,5,10]
number(first_list)