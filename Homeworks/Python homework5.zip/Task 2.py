number_1 = 100
number_2 = 999
number_3 = number_1
ammount = 0
while number_1 != number_2:
    number_1 += 1
    number_3 += 1
    while number_3 % 110 == 0:
        ammount += 1
        #print(number_3) Для проверки
        break
    while number_3 % 101 == 0:
        ammount += 1
        #print(number_3) Для проверки
        break
print(f'{ammount} - digits total with two identical digits between 100 and 999')
