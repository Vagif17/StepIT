number = int(input('Enter number:'))
num_1 = 3
num_2 = 6
