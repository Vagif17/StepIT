number_1 = 100
number_2 = 9999
number_3 = number_1
amount = 0
while number_1 != number_2:
    number_1 += 1
    number_3 += 1
    while number_3 < 1000 and number_3 % 111 == 0:
        amount += 1
        #print(number_3) Для проверки
        break
    while number_3 % 1111 == 0:
        amount += 1
        #print(number_3) Для проверки
        break
print(f'{amount} - Digits in total with all the same digits from 100 to 9999.')