first_number = int(input('Enter  X number :'))
second_number = int(input('Enter Y number :'))
numm = 1
number = first_number
while numm != second_number:
    number *= first_number
    numm += 1

print(number)