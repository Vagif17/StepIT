number = int(input('Enter number:'))
division = 1
num = 0
num_1 = 1
while number // division > 0:
    digit = (number // division) % 10
    division *= 10
    while num != digit:
        num += 1
        num_1 *= num
    print(f' factorial of {digit} = {num_1}')
    num = num - num
    num_1 = num_1 - num_1 + 1