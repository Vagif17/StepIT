number = int(input('Enter number:'))
division = 1
num = 0
num_1 = 0
while number // division > 0:
    digit = (number // division) % 10
    division *= 10
    while num != digit:
        num += 1 # Количество чисел
        num_1 += num # Сумма чисел
    print(f'Arithmetic mean {num} = {num_1 / num}')
    num = num - num
    num_1 = num_1 - num_1
