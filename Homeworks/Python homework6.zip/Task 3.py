number = int(input('Enter number:'))
division = 1
division_1 = 1
amount_number = 0
amount_number_1 = 1
amount_number_2 = 1
amount_number_3 = 2
res = 0
while number // division > 0:
    division *= 10
    amount_number += 1
division = 1
if amount_number % 2 == 0:
    while number // division > 0:
        digit = (number // division) % 10
        division *= 10
        res += digit
        break
    while amount_number_1 != amount_number:
        division_1 *= 10
        amount_number_1 += 1
    while amount_number_2 != amount_number - 1:
        digit = (number // division) % 10
        division *= 10
        division_1 //= 10
        digit *= division_1
        res += digit
        amount_number_2 += 1
    while amount_number_3 != amount_number:
        division_1 *= 10
        amount_number_3 += 1
    while amount_number_2 != amount_number:
        digit = (number // division) % 10
        digit *= division_1
        res += digit
        amount_number_2 += 1
print(res)