Number_1 = int(input('Enter first number:'))
Number_2 = int(input('Enter second number:'))
num = 0
num_1 = 0
while Number_1 != Number_2:
    Number_1 += 1
    num += Number_1
    num_1 += 1
    arifm = num / num_1
print(num)
print(arifm)

