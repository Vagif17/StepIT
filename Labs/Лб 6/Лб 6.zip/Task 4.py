#Version 1
# length = int(input('Enter line length:'))
# symbol = (input('Enter Symbol:'))
# symbol_2 = symbol
# num = 1
# while num != length:
#     symbol += symbol_2
#     num += 1
# print(symbol)

#Version 2
# length = int(input('Enter line length:'))
# symbol = (input('Enter Symbol:'))
# print(length * symbol)