#Version 1
# length = int(input('Enter line length:'))
# nam = 0
# symbol = ('*')
# while nam != length:
#     nam += 1
# print(f'{nam * symbol}')

#Version 2
# length = int(input('Enter line length:'))
# symbol = ('*')
# print(symbol * length)
